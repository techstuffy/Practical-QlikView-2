Practical QlikView 2

The purpose of these files are to provide the user with sample data to use while following the examples and to reduce the amount of typing required.



