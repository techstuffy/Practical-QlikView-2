QVX DIRECTORY LISTING - page 102

This is the full qvx example 

To use this example:



1. Open Visual Studio Express for Desktop
2. Select File-Open Project 

Go to the folder:
<extraced zip folder>\section2\section2-chapter3-qvx-custom data sources\QVX DIRECTORY LISTING\DirectoryList

3. Open DirectoryList.sln file

4.Press F5 to rebuild the project.

5. Go to the following folder:

<extraced zip folder>\section2\section2-chapter3-qvx-custom data sources\QVX DIRECTORY LISTING\DirectoryList\QvEventLogConnectorSimple\bin\Debug

Check that the QvDirectoryList.exe date modified time has updated.

If there are no errors you can continue with the example.

