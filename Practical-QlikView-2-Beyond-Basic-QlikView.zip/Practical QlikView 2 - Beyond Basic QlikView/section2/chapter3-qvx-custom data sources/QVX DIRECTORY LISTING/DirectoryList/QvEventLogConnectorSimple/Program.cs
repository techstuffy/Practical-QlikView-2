﻿using System;
using QvDirectoryList;

namespace QvDirectoryConnector
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            if (args != null && args.Length >= 2)
            {
                //Create new instance of QvDirectoryListServer which implements QvxServer and pass any arguements   
                new QvDirectoryListServer().Run(args[0], args[1]);
            }
            //else
            //{
            //    Console.WriteLine("Generate QVX file");
            //    new QvDirectoryListServer().RunStandalone("", "StandalonePipe", "", "C:\\test.qvx", "select * from DirectoryFileList");
            //}
        }
    }
}
