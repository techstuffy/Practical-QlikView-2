﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using QlikView.Qvx.QvxLibrary;
using System.IO;

namespace QvDirectoryList
{
    internal class QvDirectoryListConnection : QvxConnection
    {
        public override void Init()
        {
            QvxLog.SetLogLevels(true, true);
            QvxLog.Log(QvxLogFacility.Application, QvxLogSeverity.Notice, "Init()");


            //QVX fields that QlikView can see.
            var fileFields = new QvxField[]
                {
                    new QvxField("filename", QvxFieldType.QVX_TEXT, QvxNullRepresentation.QVX_NULL_FLAG_SUPPRESS_DATA, FieldAttrType.ASCII),                   
                    new QvxField("file_created_dttm", QvxFieldType.QVX_TEXT, QvxNullRepresentation.QVX_NULL_FLAG_SUPPRESS_DATA, FieldAttrType.ASCII)                   
                };


            MTables = new List<QvxTable>
                {
                       new QvxTable
                        {
                            //QVX Table name that will appear in QlikView
                            TableName = "DirectoryFileList",
                            GetRows = GetDirectoryFiles,
                            Fields = fileFields
                        }
                };
        }


        //Extract the data that will be shown in QlikView - in this example we are getting a directory listing.
        //Then call the MakeEntry method to create a row in the QVX table
        private IEnumerable<QvxDataRow> GetDirectoryFiles()
        {
            QvxLog.Log(QvxLogFacility.Application, QvxLogSeverity.Notice, "GetDirectoryFiles()");

            String folder_to_process_files;
            this.MParameters.TryGetValue("folder_to_process", out folder_to_process_files);

            QvxLog.Log(QvxLogFacility.Application, QvxLogSeverity.Notice, "FOLDER TO PROCESS FILES " + folder_to_process_files);
            
            string[] my_files = Directory.GetFiles(folder_to_process_files, "*");

            foreach (string file_name in my_files)
            {
                FileInfo file_info = new FileInfo(file_name);

                yield return MakeEntry(file_info.Name as String, file_info.CreationTime.ToString() as String, FindTable("DirectoryFileList", MTables));
            }
        }


        //Create a new row in the QVX Table
        private QvxDataRow MakeEntry(String filename, String file_created,QvxTable table)
        {
            var row = new QvxDataRow();
            row[table.Fields[0]] = filename;
            row[table.Fields[1]] = file_created;         
            return row;
        }


    }
}
