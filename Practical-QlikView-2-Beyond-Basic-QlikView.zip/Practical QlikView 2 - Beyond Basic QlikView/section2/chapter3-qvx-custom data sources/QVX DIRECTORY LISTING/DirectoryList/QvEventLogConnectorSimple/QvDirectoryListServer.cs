﻿using QlikView.Qvx.QvxLibrary;
using System.Windows.Forms;

namespace QvDirectoryList
{
    internal class QvDirectoryListServer : QvxServer
    {

        //Return class that implements QvxConnection , in this case the class is called QvDirectoryListConnection.
        public override QvxConnection CreateConnection()
        {
            return new QvDirectoryListConnection();
        }


        //This method returns the text for the connection string used in the loadscript
        //For example:  CUSTOM CONNECT TO "Provider=QvDirectoryList.exe;myconnectionstring=tester;XUserId=cGKWSXA;XPassword=UPFCMFD;";
        public override string CreateConnectionString()
        {
            QvxLog.Log(QvxLogFacility.Application, QvxLogSeverity.Debug, "CreateConnectionString()");
            return "folder_to_process=C:\\myfolder";
        }

 
    }
}
