Simple loadscripts for examples to save typing time:

aggr sample data.txt - page 125

alternate state sample data.txt - page 117

preceding loads example.txt - page 122

variables test data.txt - page 132