Section Access - Document Security


full basic section access loadscript.txt - page 138
section access and section application loadscript.txt - page 141
section access sample data.txt - page 137

Excel section access -  page 144
excel_section_access.xls
section access from spreadsheet.txt
