join sample data loadscript.txt - page 79

join script.txt - page 81

keep.txt - page 84