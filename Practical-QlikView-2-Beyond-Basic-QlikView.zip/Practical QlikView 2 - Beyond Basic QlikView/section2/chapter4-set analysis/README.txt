data field example.txt - page 111
The loadscript for set analysis date field example.

The sampledata.xls can be found in the '<extracted folder>\sample data spreadsheets\' folder.
