var doc;

function onDoneLoadingScripts()
{
//	alert("DONE");
}


function init() {
 doc = Qv.GetCurrentDocument();

Qva.LoadScript("/QvAjaxZfc/QvsViewClient.aspx?public=only&name=Extensions/Examples/WebPageViewer/jquery.js", onDoneLoadingScripts);
if(!jQuery)
	alert("Essential plugin (jquery) not loaded");

// Qva.LoadScript("/qvajaxzfc/qvsviewclient.aspx?public=only&name=Extensions/Examples/WebPageViewer/text-change.js", onDoneLoadingScripts);


} 

 
Qva.AddExtension('QlikView/Examples/WebPageViewer',
	function() {

			this.Element.innerHTML = "<H1>TEST JQUERY</H1>"+			
									"<h2>This is a heading</h2>"+
									"<p>This is a paragraph.</p>"+
									"<p>This is another paragraph.</p>"+
									"<button>Click me</button>";

									$(document).ready(function(){
									  $("button").click(function(){
										$("p").hide();
									  });
									});
			
		}, false);

init();
