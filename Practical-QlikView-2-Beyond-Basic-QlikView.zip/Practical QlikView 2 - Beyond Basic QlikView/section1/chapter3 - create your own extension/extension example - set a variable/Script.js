var doc;
var done_once;

function init() {
 doc = Qv.GetCurrentDocument();
} 

Qva.AddExtension('QlikView/Examples/WebPageViewer',
	function() {

			var state = this.Layout.Text0.text;

			if(state == "False" && done_once!="true")
			{			
				alert('set show_website_status to TRUE');	 			
				doc.SetVariable("show_website_status","TRUE");
				done_once = "true";
			}

		}, false);
init();
 
