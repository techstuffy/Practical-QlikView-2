Examples:

Folders:

extension example - css - see page 59
Script.js uses css file when displaying extension.

extension example - jquery - see page 61

extension example - set a variable - see page 68

extension - full example - see page 55


Files:

callback_func_Script.js - see page 66
clickme.png\htmlbutton-Script.js - see page 67