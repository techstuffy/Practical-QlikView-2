
Qva.AddExtension('QlikView/Examples/WebPageViewer', function() { 
	if(!this.framecreated)
	{
		var el = document.createElement("iframe");
		el.setAttribute('id', 'ifrm');
		el.frameBorder = 0; //optional
		el.style.width = this.GetWidth() + "px";
		el.style.height = this.GetHeight() + "px";
		this.Element.appendChild(el);
		el.setAttribute('src', this.Layout.Text0.text);
		this.framecreated = true;
	}
	else
	{
		var ifrm = document.getElementById("ifrm");
		ifrm.style.width = this.GetWidth();
		ifrm.style.height = this.GetHeight();
		ifrm.setAttribute('src', this.Layout.Text0.text);
	}
});

