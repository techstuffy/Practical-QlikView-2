Init = function() {
    doc = Qv.GetCurrentDocument();
}


Qva.AddExtension('QlikView/Examples/WebPageViewer', function() { 

var path = Qva.Remote + "?public=only&name=Extensions/QlikView/Examples/WebPageViewer/";
	this.Element.innerHTML = "<div onclick=alert(\'onclick\'); style='width=149px; height:60px;background-repeat: no-repeat; background-image:url("+path+ "clickme.png)'></div>";	
Init();

});
