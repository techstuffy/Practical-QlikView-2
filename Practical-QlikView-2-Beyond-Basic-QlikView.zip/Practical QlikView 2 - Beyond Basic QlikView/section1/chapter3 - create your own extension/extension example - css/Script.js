
Qva.AddExtension('testext', function() { 
var path = Qva.Remote + "?public=only&name=Extensions/testext/";
Qva.LoadCSS(path+"style.css");

this.Element.innerHTML =
 "<div><H1>This is the main title</H1></br><h2>This is some other text</h2></div>"; 

	 
});

