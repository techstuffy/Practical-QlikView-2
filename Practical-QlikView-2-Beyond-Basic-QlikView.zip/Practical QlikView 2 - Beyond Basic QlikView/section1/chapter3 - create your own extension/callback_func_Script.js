var callbackfunction = function () {
    alert("callback - done");
};
 
 
Qva.AddExtension('QlikView/Examples/WebPageViewer',
	function() {		 

	var doc = Qv.GetCurrentDocument();
	doc.GetObject('LB01', callbackfunction);
   
}, false);

