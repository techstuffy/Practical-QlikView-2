Samples:

sample data loadscript.txt 
The loadscript to be used with the SampleCustomerReports.xls file.

dynamic charts.txt
Dynamic charts example.

link to document.txt
The loadscript for the 'linking to images and other documents' example.


